import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';
import { motion } from 'framer-motion';
import { BrainCircuit, Mail, KeyRound, LoaderCircle, CheckCircle } from 'lucide-react';

const SignUpPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(false);
    try {
      const { error } = await supabase.auth.signUp({ email, password });
      if (error) throw error;
      setSuccess(true);
    } catch (error: any) {
      setError(error.error_description || error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-950 p-4">
      <motion.div 
        className="w-full max-w-md"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="text-center mb-8">
            <div className="inline-block p-4 bg-gray-800/50 rounded-full border border-gray-700 shadow-lg mb-4">
                <BrainCircuit className="w-12 h-12 text-cyan-400" />
            </div>
            <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-gray-200 to-gray-400 text-transparent bg-clip-text">
                Create Your Account
            </h1>
            <p className="text-lg text-gray-400 mt-2">Join Limbus and start a new conversation.</p>
        </div>

        <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-2xl p-8 shadow-2xl">
          {success ? (
            <div className="text-center">
                <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4"/>
                <h2 className="text-2xl font-semibold text-gray-100">Success!</h2>
                <p className="text-gray-400 mt-2">Please check your email for a verification link to complete your registration.</p>
                 <Link to="/login" className="font-semibold text-cyan-400 hover:text-cyan-300 transition mt-6 block">
                    Back to Sign In
                </Link>
            </div>
          ) : (
            <form onSubmit={handleSignUp} className="space-y-6">
                <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={20}/>
                    <input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg py-3 pl-10 pr-4 text-gray-200 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
                        required
                    />
                </div>
                <div className="relative">
                    <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={20}/>
                    <input
                        type="password"
                        placeholder="Password (at least 6 characters)"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg py-3 pl-10 pr-4 text-gray-200 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
                        required
                    />
                </div>
                {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                <motion.button
                type="submit"
                disabled={loading}
                whileHover={{ scale: loading ? 1 : 1.05 }}
                whileTap={{ scale: loading ? 1 : 0.95 }}
                className="w-full flex justify-center items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                {loading && <LoaderCircle className="animate-spin" size={20}/>}
                <span>{loading ? 'Creating Account...' : 'Sign Up'}</span>
                </motion.button>
            </form>
          )}
          
          <div className="text-center mt-6">
            <p className="text-sm text-gray-400">
                Already have an account?{' '}
                <Link to="/login" className="font-semibold text-cyan-400 hover:text-cyan-300 transition">
                    Sign In
                </Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default SignUpPage;
