import React, { createContext, useContext, useState, useEffect } from 'react';
import { handleTextPrompt } from '../lib/api';
import { supabase } from '../lib/supabaseClient';
import { useAuth, Profile } from './AuthContext';

export interface Message {
    id: string;
    sender: 'user' | 'ai';
    content: string;
    error?: boolean;
    created_at?: string;
    chat_id?: string;
}

export interface Chat {
    id: string;
    title: string;
}

interface ChatContextType {
    messages: Message[];
    chats: Chat[];
    loadChat: (chatId: string) => void;
    isLoading: boolean;
    error: string | null;
    currentMode: 'analyst' | 'companion';
    isConversationStarted: boolean;
    sendMessage: (prompt: string) => Promise<void>;
    setCurrentMode: (mode: 'analyst' | 'companion') => void;
    startNewChat: () => void;
    startConversation: () => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user, profile } = useAuth();
    const [messages, setMessages] = useState<Message[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [currentMode, setCurrentMode] = useState<'analyst' | 'companion'>('analyst');
    const [isConversationStarted, setIsConversationStarted] = useState(false);
    const [currentChatId, setCurrentChatId] = useState<string | null>(null);
    const [chats, setChats] = useState<Chat[]>([]);

    const fetchChats = async () => {
        if (!user) return;
        const { data, error } = await supabase
            .from('chats')
            .select('id, title')
            .eq('user_id', user.id)
            .order('created_at', { ascending: false });

        if (error) {
            console.error('Error fetching chats:', error);
        } else {
            setChats(data || []);
        }
    };

    useEffect(() => {
        if (user) {
            fetchChats();
        } else {
            setChats([]);
            startNewChat();
        }
    }, [user]);

    const loadChat = async (chatId: string) => {
        setIsLoading(true);
        const { data, error } = await supabase
            .from('messages')
            .select('*')
            .eq('chat_id', chatId)
            .order('created_at', { ascending: true });

        if (error) {
            console.error('Error loading chat:', error);
            setMessages([{id: 'error-load', sender: 'ai', content: `Failed to load chat history. Error: ${error.message}`, error: true}]);
        } else {
            setMessages(data.map(m => ({...m, id: m.id.toString()})));
        }
        setCurrentChatId(chatId);
        setIsConversationStarted(true);
        setIsLoading(false);
    };
    
    const startNewChat = () => {
        setMessages([]);
        setIsConversationStarted(false);
        setCurrentChatId(null);
    };
    
    const startConversation = () => {
        setIsConversationStarted(true);
    };

    const checkQueryLimit = async (currentProfile: Profile): Promise<{allowed: boolean, newCount?: number}> => {
        const now = new Date();
        const lastQuery = new Date(currentProfile.last_query_date);
        let currentCount = currentProfile.monthly_query_count;

        // Reset count if it's a new month
        if (now.getMonth() !== lastQuery.getMonth() || now.getFullYear() !== lastQuery.getFullYear()) {
            currentCount = 0;
        }

        if (currentProfile.subscription_tier === 'free' && currentCount >= 100) {
            return { allowed: false };
        }
        
        return { allowed: true, newCount: currentCount + 1 };
    }

    const sendMessage = async (prompt: string) => {
        if (!prompt.trim() || !user || !profile) return;

        setIsLoading(true);
        setError(null);
        
        const limitCheck = await checkQueryLimit(profile);
        if (!limitCheck.allowed) {
            const limitMessage: Message = {
                id: `limit-${Date.now()}`,
                sender: 'ai',
                content: "You have reached your monthly query limit of 100 messages for the free plan. Please upgrade to a paid plan to continue.",
                error: true,
            };
            setMessages(prev => [...prev, limitMessage]);
            setIsLoading(false);
            return;
        }

        const optimisticId = `optimistic-${Date.now()}`;
        const userMessage: Message = { id: optimisticId, sender: 'user', content: prompt };
        setMessages(prev => [...prev, userMessage]);
        
        let chatId = currentChatId;

        try {
            if (!chatId) {
                const { data: newChat, error: newChatError } = await supabase
                    .from('chats')
                    .insert({ user_id: user.id, title: prompt.substring(0, 40) + (prompt.length > 40 ? '...' : ''), mode: currentMode })
                    .select().single();
                if (newChatError) throw newChatError;
                chatId = newChat.id;
                setCurrentChatId(chatId);
                fetchChats(); // Refresh chat list
            }

            const { data: savedUserMessage, error: userMessageError } = await supabase
                .from('messages').insert({ chat_id: chatId, sender: 'user', content: prompt }).select().single();
            if (userMessageError) throw userMessageError;

            const aiResponseContent = await handleTextPrompt(prompt, currentMode);

            const { data: savedAiMessage, error: aiMessageError } = await supabase
                .from('messages').insert({ chat_id: chatId, sender: 'ai', content: aiResponseContent }).select().single();
            if (aiMessageError) throw aiMessageError;

            // Increment query count in the database
            await supabase.from('profiles').update({ 
                monthly_query_count: limitCheck.newCount,
                last_query_date: new Date().toISOString()
            }).eq('id', user.id);

            // Replace optimistic message with final and add AI response
            setMessages(prev => {
                const newMessages = prev.filter(m => m.id !== optimisticId);
                return [
                    ...newMessages,
                    { ...savedUserMessage, id: savedUserMessage.id.toString() },
                    { ...savedAiMessage, id: savedAiMessage.id.toString() }
                ];
            });

        } catch (err: any) {
            const errorMessage: Message = {
                id: `error-${Date.now()}`,
                sender: 'ai',
                content: `An error occurred: ${err.message || 'Unknown error'}`,
                error: true,
            };
            setMessages(prev => [...prev.filter(m => m.id !== optimisticId), errorMessage]);
            setError("An error occurred: " + (err.message || 'Unknown error'));
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <ChatContext.Provider value={{ messages, isLoading, error, currentMode, isConversationStarted, sendMessage, setCurrentMode, startNewChat, startConversation, chats, loadChat }}>
            {children}
        </ChatContext.Provider>
    );
};

export const useChat = () => {
    const context = useContext(ChatContext);
    if (context === undefined) {
        throw new Error('useChat must be used within a ChatProvider');
    }
    return context;
};
