import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://zqntygpsqthwpgjbxcux.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpxbnR5Z3BzcXRod3BnamJ4Y3V4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjExOTY1MDUsImV4cCI6MjA3Njc3MjUwNX0.f0Qm-whLRtB350JOft6vFs28-ze4ixjuwaI9fKxP2z4';

if (!supabaseUrl || !supabaseAnonKey) {
    throw new Error("Supabase credentials are not configured.");
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);