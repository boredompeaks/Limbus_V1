import React from 'react';

const LimbusLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    width="100"
    height="100"
    viewBox="0 0 100 100"
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    {...props}
  >
    <title>Limbus_V1 Logo</title>
    <defs>
      <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{ stopColor: '#2563EB' }} />
        <stop offset="100%" style={{ stopColor: '#14B8A6' }} />
      </linearGradient>
    </defs>
    <path
      stroke="url(#logoGradient)"
      strokeWidth="8"
      strokeLinecap="round"
      strokeLinejoin="round"
      d="
        M 30 20
        Q 40 20, 45 30
        T 50 40
        Q 55 50, 60 55
        T 70 60
        M 50 40
        C 40 45, 35 55, 35 65
        Q 35 75, 45 80
        M 50 40
        C 60 42, 70 45, 75 50
        Q 80 55, 80 65
        M 30 20
        L 30 80
      "
    />
    <circle cx="30" cy="20" r="5" fill="url(#logoGradient)" />
    <circle cx="30" cy="80" r="5" fill="url(#logoGradient)" />
    <circle cx="45" cy="80" r="5" fill="url(#logoGradient)" />
    <circle cx="70" cy="60" r="5" fill="url(#logoGradient)" />
    <circle cx="80" cy="65" r="5" fill="url(#logoGradient)" />
    <circle cx="50" cy="40" r="6" fill="white" />
    <circle cx="50" cy="40" r="3" fill="url(#logoGradient)" />
  </svg>
);

export default LimbusLogo;
