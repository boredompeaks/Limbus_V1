import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { User, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';
import LimbusLogo from './LimbusLogo';

interface MessageProps {
  sender: 'user' | 'ai';
  content: string;
  error?: boolean;
}

const Message: React.FC<MessageProps> = ({ sender, content, error }) => {
  const isUser = sender === 'user';

  const AILogo = () => (
     <div className="w-full h-full p-0.5">
       <LimbusLogo />
     </div>
  );

  return (
    <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
    >
      <div className={`flex items-start gap-3 my-4 ${isUser ? 'justify-end' : 'justify-start'}`}>
        {!isUser && (
          <div className={`flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-full border ${error ? 'bg-red-900/50 border-red-700' : 'bg-gray-800 border-gray-700'}`}>
            {error ? <AlertTriangle size={18} className="text-red-400" /> : <AILogo />}
          </div>
        )}
        <div className={`max-w-lg md:max-w-xl lg:max-w-2xl px-4 py-3 rounded-2xl ${
            isUser ? 'bg-blue-600 text-white rounded-br-none' : 
            error ? 'bg-red-900/50 border border-red-800 text-red-300 rounded-bl-none' :
            'bg-gray-800 text-gray-200 rounded-bl-none'
        }`}>
          {error ? (
             <p>{content}</p>
          ) : (
            <article className="prose prose-sm prose-invert prose-p:my-2 prose-headings:my-3 prose-li:my-1 prose-pre:bg-gray-900/70 prose-pre:p-3 prose-pre:rounded-md">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{content}</ReactMarkdown>
            </article>
          )}
        </div>
        {isUser && (
          <div className="flex-shrink-0 w-8 h-8 flex items-center justify-center bg-gray-700 rounded-full border border-gray-600">
            <User size={18} className="text-gray-300" />
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default Message;
