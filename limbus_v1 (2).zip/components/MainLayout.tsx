import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Sidebar from './Sidebar';
import ChatInterface from './ChatInterface';
import NewChatScreen from './NewChatScreen';
import { useChat } from '../contexts/ChatContext';

const MainLayout: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { isConversationStarted } = useChat();

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="flex h-screen w-full bg-gray-950 text-gray-200 overflow-hidden">
      <Sidebar isMobileOpen={isSidebarOpen} onClose={toggleSidebar} />
      <motion.main
        className="flex-1 flex flex-col relative"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        {isConversationStarted ? <ChatInterface toggleSidebar={toggleSidebar} /> : <NewChatScreen />}
      </motion.main>
    </div>
  );
};

export default MainLayout;
