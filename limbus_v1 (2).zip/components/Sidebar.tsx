import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Pin, Plus, MessageSquare, ChevronsLeft, ChevronsRight, User, Settings, LogOut } from 'lucide-react';
import Logo from './Logo';
import { useAuth } from '../contexts/AuthContext';
import { useAppContext } from '../contexts/AppContext';
import { supabase } from '../lib/supabaseClient';
import { useChat } from '../contexts/ChatContext';

interface SidebarProps {
  isMobileOpen: boolean;
  onClose: () => void;
}

const SidebarUI: React.FC<{isExpanded: boolean; onToggleExpand: () => void; isPinned: boolean; onTogglePin: () => void; isMobile: boolean}> = ({isExpanded, onToggleExpand, isPinned, onTogglePin, isMobile}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user } = useAuth();
  const { startNewChat, chats, loadChat } = useChat();
  const { setIsSettingsOpen } = useAppContext();
  const navigate = useNavigate();

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
        console.error("Error logging out:", error);
    } else {
        navigate('/login');
    }
  }
  
  const handleNewChat = () => {
    startNewChat();
  }

  return (
     <div className="h-full bg-gray-900/70 backdrop-blur-sm border-r border-gray-800 flex flex-col">
        {/* Top Section */}
        <div className="flex flex-col">
            <div className={`flex items-center w-full h-24 px-4 ${isExpanded ? 'justify-between' : 'justify-center'}`}>
                <Logo isCollapsed={!isExpanded} />
                {isExpanded && !isMobile && (
                    <motion.button whileHover={{scale: 1.1}} whileTap={{scale: 0.9}} onClick={onTogglePin} className="text-gray-400 hover:text-cyan-400 transition-colors p-2 rounded-full -mr-2">
                        <motion.div animate={{ rotate: isPinned ? 45 : 0 }}>
                            <Pin size={20} />
                        </motion.div>
                    </motion.button>
                )}
            </div>
            
            <div className="px-4 mb-4">
                <motion.button onClick={handleNewChat} whileHover={{scale: 1.03}} whileTap={{scale: 0.97}} className={`w-full flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-white font-semibold transition-all duration-200 overflow-hidden ${isExpanded ? 'justify-start' : 'justify-center'}`}>
                    <Plus size={20} className="flex-shrink-0" />
                    {isExpanded && <span className="whitespace-nowrap">New Chat</span>}
                </motion.button>
            </div>
        </div>

        {/* Chat History */}
        <nav className="flex-grow px-4 mt-2 overflow-y-auto overflow-x-hidden" style={{ scrollbarWidth: 'thin' }}>
            <ul className="space-y-2">
            {chats.map((chat) => (
                <li key={chat.id}>
                    <button onClick={() => loadChat(chat.id)} className="w-full flex items-center gap-3 p-2 rounded-md text-gray-400 hover:bg-gray-800 hover:text-gray-100 transition-colors text-left">
                        <MessageSquare size={20} className="flex-shrink-0" />
                        {isExpanded && <span className="truncate text-sm">{chat.title}</span>}
                    </button>
                </li>
            ))}
            </ul>
        </nav>

        {/* Bottom Section */}
        <div className="mt-auto p-4 border-t border-gray-800">
            <div className="relative">
                <AnimatePresence>
                {isMenuOpen && isExpanded && (
                    <motion.div 
                        className="absolute bottom-full left-0 right-0 mb-2 bg-gray-800 border border-gray-700 rounded-lg shadow-lg z-10"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        transition={{ duration: 0.2 }}
                    >
                        <ul className="py-1">
                            <li>
                                <button className="w-full flex items-center gap-3 px-4 py-2 text-sm text-gray-300 hover:bg-gray-700/50" onClick={() => { setIsSettingsOpen(true); setIsMenuOpen(false); }}>
                                    <Settings size={16} />
                                    <span>Settings</span>
                                </button>
                            </li>
                            <li>
                                <button onClick={handleLogout} className="w-full flex items-center gap-3 px-4 py-2 text-sm text-red-400 hover:bg-red-900/50 hover:text-red-300">
                                    <LogOut size={16} />
                                    <span>Logout</span>
                                </button>
                            </li>
                        </ul>
                    </motion.div>
                )}
                </AnimatePresence>
                <div className="flex items-center">
                    <motion.button whileTap={{backgroundColor: '#27272a'}} onClick={() => setIsMenuOpen(!isMenuOpen)} className="flex-1 flex items-center min-w-0 text-left p-2 rounded-lg hover:bg-gray-800 transition-colors">
                        <div className="p-2 bg-gray-700 rounded-full flex-shrink-0">
                          <User size={24} className="text-gray-300" />
                        </div>
                        {isExpanded && (
                            <div className="ml-3 overflow-hidden flex-1">
                                <p className="text-sm font-semibold text-gray-200 truncate">{user?.email}</p>
                            </div>
                        )}
                    </motion.button>
                   {!isMobile && (
                    <motion.button whileHover={{scale: 1.1}} whileTap={{scale: 0.9}} onClick={onToggleExpand} className="p-2 text-gray-400 hover:text-gray-100 rounded-md ml-auto flex-shrink-0">
                        {isExpanded ? <ChevronsLeft size={20} /> : <ChevronsRight size={20} />}
                    </motion.button>
                   )}
                </div>
            </div>
        </div>
    </div>
  )
}

const Sidebar: React.FC<SidebarProps> = ({ isMobileOpen, onClose }) => {
    const { isSidebarCollapsed, setIsSidebarCollapsed, isSidebarPinned, setIsSidebarPinned } = useAppContext();
    
    const handleMouseEnter = () => {
        if (!isSidebarPinned) setIsSidebarCollapsed(false);
    };

    const handleMouseLeave = () => {
        if (!isSidebarPinned) setIsSidebarCollapsed(true);
    };
    
    const handleTogglePin = () => {
        setIsSidebarPinned(prev => {
            if (!prev) setIsSidebarCollapsed(false);
            return !prev;
        });
    }

    const handleToggleExpand = () => {
        if (!isSidebarCollapsed) setIsSidebarPinned(false);
        setIsSidebarCollapsed(prev => !prev);
    }
    
    return (
        <>
            {/* Mobile Sidebar */}
            <AnimatePresence>
                {isMobileOpen && (
                    <>
                        <motion.div 
                            className="fixed inset-0 bg-black/60 z-40 md:hidden"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            onClick={onClose}
                        />
                        <motion.div
                            className="fixed inset-y-0 left-0 z-50 md:hidden w-64"
                            initial={{ x: '-100%' }}
                            animate={{ x: 0 }}
                            exit={{ x: '-100%' }}
                            transition={{ duration: 0.3, ease: 'easeInOut' }}
                        >
                            <SidebarUI isExpanded={true} onToggleExpand={() => {}} isPinned={true} onTogglePin={() => {}} isMobile={true}/>
                        </motion.div>
                    </>
                )}
            </AnimatePresence>
            
            {/* Desktop Sidebar */}
            <div className="relative hidden md:flex">
                <motion.aside
                    animate={{ width: !isSidebarCollapsed ? '16rem' : '5rem' }}
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    onMouseEnter={handleMouseEnter}
                    onMouseLeave={handleMouseLeave}
                >
                    <SidebarUI
                        isExpanded={!isSidebarCollapsed}
                        onToggleExpand={handleToggleExpand}
                        isPinned={isSidebarPinned}
                        onTogglePin={handleTogglePin}
                        isMobile={false}
                    />
                </motion.aside>
            </div>
        </>
    )
}


export default Sidebar;