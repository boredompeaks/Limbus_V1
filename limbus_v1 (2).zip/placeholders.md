# Limbus_V1 Placeholders

This file tracks features that have been planned and have placeholders in the code but are not yet fully implemented.

- **Second AI Model for Transcription**
  - **Reference**: `lib/api.ts` (conceptual), `ChatContext.tsx` (tier-based logic).
  - **Description**: Placeholder for a different, potentially more advanced or specialized AI model to be used for voice transcription. This feature is intended for 'Basic' and 'Pro' tier users, offering a different capability than the standard model.
