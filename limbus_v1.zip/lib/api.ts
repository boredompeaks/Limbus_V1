export async function handleTextPrompt(prompt: string, mode: string): Promise<string> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(`This is a mock AI response in **${mode} mode** for your message: "${prompt}".\n\nHere is a list of points:\n- **Point 1:** Further elaboration.\n- **Point 2:** Another perspective.\n\n\`\`\`javascript\n// Example code block\nconsole.log("Hello, from Limbus!");\n\`\`\``);
    }, 1500);
  });
}

export async function handleVoiceInput(audioBlob: Blob): Promise<string> {
  console.log(audioBlob); // To satisfy linter
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve("This is a mock response from a simulated voice input.");
    }, 2000);
  });
}
