import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ChatProvider } from './contexts/ChatContext';
import { AppProvider, useAppContext } from './contexts/AppContext';
import LoadingScreen from './components/LoadingScreen';
import MainLayout from './components/MainLayout';
import LoginPage from './pages/LoginPage';
import SettingsModal from './components/SettingsModal';

const AppRoutes: React.FC = () => {
  const { session, loading } = useAuth();
  const { isSettingsOpen } = useAppContext();

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <>
      <Routes>
        <Route path="/login" element={!session ? <LoginPage /> : <Navigate to="/" />} />
        <Route path="/" element={session ? <MainLayout /> : <Navigate to="/login" />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      {isSettingsOpen && <SettingsModal />}
    </>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <AppProvider>
        <ChatProvider>
          <div className="bg-gray-950 text-gray-200 min-h-screen font-sans">
            <AppRoutes />
          </div>
        </ChatProvider>
      </AppProvider>
    </AuthProvider>
  );
};

export default App;
