import React from 'react';
import { motion } from 'framer-motion';
import { BrainCircuit, Users } from 'lucide-react';
import Logo from './Logo';
import { useChat } from '../contexts/ChatContext';

const NewChatScreen: React.FC = () => {
  const { setCurrentMode, startConversation } = useChat();

  const handleModeSelect = (mode: 'analyst' | 'companion') => {
    setCurrentMode(mode);
    startConversation();
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center text-center p-4 h-full">
      <div className="mb-8">
        <Logo isCollapsed={false} />
      </div>
      <h1 className="text-4xl md:text-5xl font-bold tracking-tight bg-gradient-to-r from-gray-200 to-gray-400 text-transparent bg-clip-text mb-4">
        How can I help you today?
      </h1>
      <div className="grid md:grid-cols-2 gap-6 mt-8 w-full max-w-2xl">
        <motion.button
          whileHover={{ scale: 1.03, y: -5 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => handleModeSelect('analyst')}
          className="bg-gray-900/50 border border-gray-800 p-8 rounded-2xl flex flex-col items-center text-center hover:border-cyan-500 transition-all duration-300"
        >
          <div className="p-3 bg-blue-600/20 rounded-xl mb-4 border border-blue-500/30">
            <BrainCircuit size={32} className="text-blue-400" />
          </div>
          <h2 className="text-xl font-semibold text-gray-100 mb-2">Analyst Mode</h2>
          <p className="text-gray-400">Deep, structured psychological analysis.</p>
        </motion.button>
        
        <motion.div
          className="bg-gray-900/50 border border-gray-800 p-8 rounded-2xl flex flex-col items-center text-center opacity-50 cursor-not-allowed relative"
        >
           <div className="absolute top-3 right-3 bg-yellow-500 text-gray-900 text-xs font-bold px-2 py-1 rounded-full">
                Coming Soon
            </div>
          <div className="p-3 bg-gray-700/20 rounded-xl mb-4 border border-gray-600/30">
            <Users size={32} className="text-gray-500" />
          </div>
          <h2 className="text-xl font-semibold text-gray-400 mb-2">Companion Mode</h2>
          <p className="text-gray-500">Empathetic, supportive conversation.</p>
        </motion.div>
      </div>
    </div>
  );
};

export default NewChatScreen;
