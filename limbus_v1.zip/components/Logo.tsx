import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import LimbusLogo from './LimbusLogo';

interface LogoProps {
  isCollapsed: boolean;
}

const Logo: React.FC<LogoProps> = ({ isCollapsed }) => {
  return (
    <div className="flex items-center gap-2 overflow-hidden">
      <div className="w-10 h-10 flex-shrink-0">
        <LimbusLogo />
      </div>
      <AnimatePresence>
        {!isCollapsed && (
          <motion.span
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2, ease: 'easeInOut' }}
            className="font-bold text-xl tracking-wider text-gray-200"
          >
            Limbus_V1
          </motion.span>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Logo;
