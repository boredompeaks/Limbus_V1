import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, ArrowUp, Menu } from 'lucide-react';
import TextareaAutosize from 'react-textarea-autosize';
import Message from './Message';
import { useChat } from '../contexts/ChatContext';
import TypingIndicator from './TypingIndicator';

interface ChatInterfaceProps {
  toggleSidebar: () => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ toggleSidebar }) => {
  const { messages, isLoading, sendMessage } = useChat();
  const [input, setInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = () => {
    if (isLoading || !input.trim()) return;
    sendMessage(input);
    setInput('');
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  }

  return (
    <div className="flex flex-col h-full w-full overflow-hidden bg-gray-950">
      {/* Header */}
      <header className="flex items-center p-4 border-b border-gray-800 md:hidden">
          <motion.button whileHover={{scale: 1.1}} whileTap={{scale: 0.9}} onClick={toggleSidebar} className="p-2 text-gray-400 hover:text-white">
              <Menu size={24} />
          </motion.button>
          <h2 className="text-lg font-semibold ml-4">Limbus_V1</h2>
      </header>

      {/* Chat Display Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6">
        <div className="max-w-3xl mx-auto">
            <div>
              <AnimatePresence>
                {messages.map((msg) => (
                  <Message key={msg.id} sender={msg.sender} content={msg.content} error={msg.error} />
                ))}
              </AnimatePresence>
              {isLoading && <TypingIndicator />}
              <div ref={chatEndRef} />
            </div>
        </div>
      </div>

      {/* Input Area */}
      <div className="w-full p-4 md:p-6 bg-gray-950/80 backdrop-blur-sm border-t border-gray-800">
        <div className="max-w-3xl mx-auto">
          {/* Prompt Box */}
          <div className="relative flex items-end w-full p-2 bg-gray-900 rounded-2xl border border-gray-700 shadow-md focus-within:border-cyan-500 transition-colors">
            <TextareaAutosize
              className="flex-1 w-full bg-transparent text-gray-200 placeholder-gray-500 resize-none border-none focus:ring-0 pl-3 pr-20 py-2 text-base"
              placeholder="Ask about your feelings, thoughts, or psychological concepts..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              maxRows={5}
              rows={1}
            />
            <div className="absolute right-3 bottom-3 flex items-center">
                <AnimatePresence mode="wait">
                    {input.trim() ? (
                        <motion.button
                            key="submit"
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.8 }}
                            transition={{ duration: 0.2 }}
                            whileHover={{ scale: 1.1, backgroundColor: '#1d4ed8' }}
                            whileTap={{ scale: 0.9 }}
                            onClick={handleSendMessage}
                            className="p-2.5 rounded-full bg-blue-600 text-white focus:outline-none focus:ring-2 focus:ring-blue-400"
                            disabled={isLoading}
                        >
                            <ArrowUp size={20} />
                        </motion.button>
                    ) : (
                        <motion.button
                            key="mic"
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.8 }}
                            transition={{ duration: 0.2 }}
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            className="p-2.5 rounded-full text-gray-400 hover:text-cyan-400 focus:outline-none"
                        >
                             <motion.div
                                animate={{ scale: [1, 1.05, 1] }}
                                transition={{
                                    duration: 1.5,
                                    repeat: Infinity,
                                    ease: 'easeInOut',
                                }}
                                className="rounded-full"
                            >
                               <Mic size={20} />
                            </motion.div>
                        </motion.button>
                    )}
                </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;