import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, User, Palette, Puzzle, ShieldCheck, Info, FileDown, Trash2, ShieldAlert } from 'lucide-react';
import { useAppContext } from '../contexts/AppContext';

// Helper components for settings UI
const SettingsRow: React.FC<{label: string, description: string, children: React.ReactNode}> = ({label, description, children}) => (
    <div className="flex justify-between items-center py-4 border-b border-gray-800">
        <div>
            <h4 className="font-semibold text-gray-200">{label}</h4>
            <p className="text-sm text-gray-500">{description}</p>
        </div>
        <div>
            {children}
        </div>
    </div>
);

const ToggleSwitch: React.FC<{enabled: boolean, setEnabled: (val: boolean) => void}> = ({enabled, setEnabled}) => (
    <div onClick={() => setEnabled(!enabled)} className={`w-12 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${enabled ? 'bg-blue-600' : 'bg-gray-700'}`}>
        <motion.div layout className={`w-4 h-4 bg-white rounded-full shadow-md`} />
    </div>
);

const SegmentedControl: React.FC<{options: string[], selected: string, setSelected: (val: string) => void}> = ({options, selected, setSelected}) => (
    <div className="flex items-center bg-gray-800 p-1 rounded-lg">
        {options.map(option => (
            <button key={option} onClick={() => setSelected(option)} className={`relative px-4 py-1.5 text-sm font-semibold rounded-md transition-colors ${selected === option ? 'text-white' : 'text-gray-400 hover:text-gray-200'}`}>
                {selected === option && <motion.div layoutId="segment-Highlighter" className="absolute inset-0 bg-gray-700 rounded-md z-0" />}
                <span className="relative z-10">{option}</span>
            </button>
        ))}
    </div>
);

const DangerButton: React.FC<{label: string, icon: React.ElementType}> = ({label, icon: Icon}) => (
    <motion.button 
        whileHover={{scale: 1.05}} whileTap={{scale: 0.95}}
        className="flex items-center gap-2 px-4 py-2 text-sm font-semibold bg-red-900/50 text-red-400 border border-red-800 rounded-lg hover:bg-red-900 hover:text-red-300 transition-colors">
        <Icon size={16}/> {label}
    </motion.button>
);


const SettingsModal: React.FC = () => {
  const { setIsSettingsOpen } = useAppContext();
  const [currentTab, setCurrentTab] = useState('Account');
  
  // Mock states for UI
  const [colorMode, setColorMode] = useState('Dark');
  const [highContrast, setHighContrast] = useState(false);
  const [defaultMode, setDefaultMode] = useState('Analyst');
  const [disableHistory, setDisableHistory] = useState(false);
  const [responseLength, setResponseLength] = useState('Default');


  const tabs = [
    { name: 'Account', icon: User },
    { name: 'Appearance', icon: Palette },
    { name: 'Behavior', icon: Puzzle },
    { name: 'Data & Privacy', icon: ShieldCheck },
    { name: 'About', icon: Info },
  ];

  const renderContent = () => {
    switch (currentTab) {
      case 'Account':
        return <div className="space-y-4">
            <SettingsRow label="Display Name" description="This will be your name across Limbus.">
                 <input type="text" defaultValue="User" className="bg-gray-800 border border-gray-700 rounded-lg py-2 px-3 text-gray-200 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition w-52" />
            </SettingsRow>
            <SettingsRow label="Profile Picture" description="Upload a new avatar.">
                <button className="px-4 py-2 text-sm font-semibold bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors">Upload</button>
            </SettingsRow>
            <SettingsRow label="Change Password" description="Update your account security.">
                 <button className="px-4 py-2 text-sm font-semibold bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors">Change</button>
            </SettingsRow>
            <div className="pt-6 mt-4 border-t border-gray-800">
                <SettingsRow label="Delete Account" description="Permanently delete your account and all data.">
                    <DangerButton label="Delete" icon={ShieldAlert} />
                </SettingsRow>
            </div>
        </div>;
      case 'Appearance':
        return <div className="space-y-4">
            <SettingsRow label="Color Mode" description="Choose a light, dark, or system default theme.">
                <SegmentedControl options={['Light', 'Dark', 'System']} selected={colorMode} setSelected={setColorMode} />
            </SettingsRow>
             <SettingsRow label="Text Size" description="Adjust the application text size for readability.">
                <div className="w-52 flex items-center gap-2">
                    <span className="text-sm">A</span>
                    <input type="range" className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-cyan-500" />
                    <span className="text-xl">A</span>
                </div>
            </SettingsRow>
            <SettingsRow label="High Contrast Mode" description="Improve visibility with higher contrast colors.">
                <ToggleSwitch enabled={highContrast} setEnabled={setHighContrast} />
            </SettingsRow>
        </div>;
      case 'Behavior':
         return <div className="space-y-4">
            <SettingsRow label="Default Mode" description="Choose which mode new chats will start in.">
                <SegmentedControl options={['Analyst', 'Companion']} selected={defaultMode} setSelected={setDefaultMode} />
            </SettingsRow>
            <SettingsRow label="Disable History" description="Chats will not be saved to your account.">
                <ToggleSwitch enabled={disableHistory} setEnabled={setDisableHistory} />
            </SettingsRow>
             <SettingsRow label="Response Length" description="Set the default verbosity of AI responses.">
                <SegmentedControl options={['Concise', 'Default', 'Detailed']} selected={responseLength} setSelected={setResponseLength} />
            </SettingsRow>
        </div>;
      case 'Data & Privacy':
        return <div className="space-y-4">
            <SettingsRow label="Clear All Chat History" description="Permanently delete all your past conversations.">
                <DangerButton label="Clear History" icon={Trash2} />
            </SettingsRow>
             <SettingsRow label="Export All Chats" description="Download a JSON file of all your conversations.">
                <motion.button whileHover={{scale: 1.05}} whileTap={{scale: 0.95}} className="flex items-center gap-2 px-4 py-2 text-sm font-semibold bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors">
                    <FileDown size={16}/> Export Data
                </motion.button>
            </SettingsRow>
            <div className="pt-6 mt-4 border-t border-gray-800 text-sm text-gray-400 space-y-2">
                <a href="#" className="underline hover:text-cyan-400">Privacy Policy</a>
                <span className="mx-2">•</span>
                <a href="#" className="underline hover:text-cyan-400">Terms of Service</a>
            </div>
        </div>;
      case 'About':
        return <div className="text-gray-400 space-y-4">
            <p><span className="font-semibold text-gray-200">Version:</span> Limbus_V1</p>
            <p>A Psychology AI Analyst and Companion designed to provide insights and support.</p>
            <div>
                 <a href="#" className="text-blue-400 hover:underline">Help Center</a>
                 <span className="mx-2 text-gray-600">•</span>
                 <a href="#" className="text-blue-400 hover:underline">Contact Support</a>
            </div>
        </div>;
      default:
        return null;
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 flex items-center justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={() => setIsSettingsOpen(false)}
      >
        <motion.div
          className="relative bg-gray-900 rounded-lg shadow-xl z-50 w-full max-w-4xl h-[80vh] flex overflow-hidden border border-gray-800"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Sidebar */}
          <div className="w-1/4 bg-gray-950/50 p-4 border-r border-gray-800">
            <h2 className="text-xl font-bold mb-6 px-2">Settings</h2>
            <nav>
              <ul>
                {tabs.map((tab) => (
                  <li key={tab.name}>
                    <button
                      onClick={() => setCurrentTab(tab.name)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                        currentTab === tab.name
                          ? 'bg-blue-600 text-white'
                          : 'text-gray-400 hover:bg-gray-800 hover:text-gray-200'
                      }`}
                    >
                      <tab.icon size={18} />
                      <span>{tab.name}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
          </div>

          {/* Content */}
          <div className="w-3/4 p-8 overflow-y-auto">
             <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold">{currentTab}</h3>
                <motion.button
                    whileHover={{ scale: 1.1, rotate: 90 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setIsSettingsOpen(false)}
                    className="p-2 rounded-full text-gray-400 hover:bg-gray-800"
                >
                    <X size={20} />
                </motion.button>
             </div>
            {renderContent()}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default SettingsModal;
