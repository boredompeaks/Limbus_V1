import React from 'react';
import { motion } from 'framer-motion';
import LimbusLogo from './LimbusLogo';

const TypingIndicator: React.FC = () => {
  const AILogo = () => (
     <div className="w-full h-full p-0.5">
       <LimbusLogo />
     </div>
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex items-start gap-3 my-4 justify-start"
    >
      <div className="flex-shrink-0 w-8 h-8 flex items-center justify-center bg-gray-800 rounded-full border border-gray-700">
        <AILogo />
      </div>
      <div className="max-w-lg px-4 py-3 rounded-2xl bg-gray-800 text-gray-400 rounded-bl-none flex items-center gap-1.5">
        <span>Limbus is thinking</span>
        <motion.div
          animate={{ y: [-2, 2, -2] }}
          transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut' }}
          className="font-bold"
        >
          .
        </motion.div>
        <motion.div
          animate={{ y: [-2, 2, -2] }}
          transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut', delay: 0.2 }}
          className="font-bold"
        >
          .
        </motion.div>
        <motion.div
          animate={{ y: [-2, 2, -2] }}
          transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut', delay: 0.4 }}
          className="font-bold"
        >
          .
        </motion.div>
      </div>
    </motion.div>
  );
};

export default TypingIndicator;
