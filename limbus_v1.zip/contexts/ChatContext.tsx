import React, { createContext, useContext, useState, useEffect } from 'react';
import { handleTextPrompt } from '../lib/api';
import { supabase } from '../lib/supabaseClient';
import { useAuth } from './AuthContext';

export interface Message {
    id: string;
    sender: 'user' | 'ai';
    content: string;
    error?: boolean;
    created_at?: string;
    chat_id?: string;
}

export interface Chat {
    id: string;
    title: string;
}

interface ChatContextType {
    messages: Message[];
    chats: Chat[];
    loadChat: (chatId: string) => void;
    isLoading: boolean;
    error: string | null;
    currentMode: 'analyst' | 'companion';
    isConversationStarted: boolean;
    sendMessage: (prompt: string) => Promise<void>;
    setCurrentMode: (mode: 'analyst' | 'companion') => void;
    startNewChat: () => void;
    startConversation: () => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user } = useAuth();
    const [messages, setMessages] = useState<Message[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [currentMode, setCurrentMode] = useState<'analyst' | 'companion'>('analyst');
    const [isConversationStarted, setIsConversationStarted] = useState(false);
    const [currentChatId, setCurrentChatId] = useState<string | null>(null);
    const [chats, setChats] = useState<Chat[]>([]);

    const fetchChats = async () => {
        if (!user) return;
        const { data, error } = await supabase
            .from('chats')
            .select('id, title')
            .eq('user_id', user.id)
            .order('created_at', { ascending: false });

        if (error) {
            console.error('Error fetching chats:', error);
        } else {
            setChats(data || []);
        }
    };

    useEffect(() => {
        if (user) {
            fetchChats();
        } else {
            setChats([]);
            startNewChat();
        }
    }, [user]);

    const loadChat = async (chatId: string) => {
        setIsLoading(true);
        const { data, error } = await supabase
            .from('messages')
            .select('*')
            .eq('chat_id', chatId)
            .order('created_at', { ascending: true });

        if (error) {
            console.error('Error loading chat:', error);
            setMessages([{id: 'error-load', sender: 'ai', content: `Failed to load chat history. Error: ${error.message}`, error: true}]);
        } else {
            setMessages(data.map(m => ({...m, id: m.id.toString()})));
        }
        setCurrentChatId(chatId);
        setIsConversationStarted(true);
        setIsLoading(false);
    };
    
    const startNewChat = () => {
        setMessages([]);
        setIsConversationStarted(false);
        setCurrentChatId(null);
    };
    
    const startConversation = () => {
        setIsConversationStarted(true);
    };

    const sendMessage = async (prompt: string) => {
        if (!prompt.trim() || !user) return;

        const optimisticId = `optimistic-${Date.now()}`;
        const userMessage: Message = {
            id: optimisticId,
            sender: 'user',
            content: prompt,
        };
        setMessages(prev => [...prev, userMessage]);
        setIsLoading(true);
        setError(null);

        let chatId = currentChatId;

        try {
            if (!chatId) {
                const { data: newChat, error: newChatError } = await supabase
                    .from('chats')
                    .insert({ 
                        user_id: user.id, 
                        title: prompt.substring(0, 40) + (prompt.length > 40 ? '...' : ''), 
                        mode: currentMode 
                    })
                    .select()
                    .single();

                if (newChatError) throw newChatError;
                chatId = newChat.id;
                setCurrentChatId(chatId);
                await fetchChats(); // Refresh sidebar with new chat
            }

            // Save user message
            const { data: savedUserMessage, error: userMessageError } = await supabase
                .from('messages')
                .insert({ chat_id: chatId, sender: 'user', content: prompt })
                .select()
                .single();

            if (userMessageError) throw userMessageError;

            // Get AI response
            const aiResponseContent = await handleTextPrompt(prompt, currentMode);

            // Save AI message
            const { data: savedAiMessage, error: aiMessageError } = await supabase
                .from('messages')
                .insert({ chat_id: chatId, sender: 'ai', content: aiResponseContent })
                .select()
                .single();
            
            if (aiMessageError) throw aiMessageError;

            // Perform a single, atomic state update after all async operations are complete
            setMessages(prev => [
                ...prev.filter(m => m.id !== optimisticId), // Remove optimistic message
                { ...savedUserMessage, id: savedUserMessage.id.toString() }, // Add real user message
                { ...savedAiMessage, id: savedAiMessage.id.toString() } // Add real AI message
            ]);

        } catch (err: any) {
            const errorMessage: Message = {
                id: (Date.now() + 1).toString(),
                sender: 'ai',
                content: `An error occurred. Please check your Supabase project's database settings (especially Row Level Security policies).\n\n**Details:** ${err.message || 'Unknown error'}`,
                error: true,
            };
            // Revert optimistic update and show error
            setMessages(prev => [...prev.filter(m => m.id !== optimisticId), errorMessage]);
            setError("An error occurred: " + (err.message || 'Unknown error'));
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <ChatContext.Provider value={{ messages, isLoading, error, currentMode, isConversationStarted, sendMessage, setCurrentMode, startNewChat, startConversation, chats, loadChat }}>
            {children}
        </ChatContext.Provider>
    );
};

export const useChat = () => {
    const context = useContext(ChatContext);
    if (context === undefined) {
        throw new Error('useChat must be used within a ChatProvider');
    }
    return context;
};